# DATABASE CHAPLIN
USE Chaplin;

# Tabela de Clientes
insert into clientes (nome, email, senha_hash, telefone) values
('Lucas Almeida', 'lucas.almeida@email.com', 's101a', '(14) 99101-1001'),
('Mariana Costa', 'mariana.costa@email.com', 'm102b', '(14) 99102-1002'),
('Rafael Souza', 'rafael.souza@email.com', 'r103c', '(14) 99103-1003'),
('Beatriz Ferreira', 'beatriz.ferreira@email.com', 'b104d', '(14) 99104-1004'),
('Gabriel Oliveira', 'gabriel.oliveira@email.com', 'g105e', '(14) 99105-1005'),
('Camila Rocha', 'camila.rocha@email.com', 'c106f', '(14) 99106-1006'),
('Thiago Mendes', 'thiago.mendes@email.com', 't107g', '(14) 99107-1007'),
('Fernanda Lima', 'fernanda.lima@email.com', 'f108h', '(14) 99108-1008'),
('Gustavo Martins', 'gustavo.martins@email.com', 'u109i', '(14) 99109-1009'),
('Amanda Pereira', 'amanda.pereira@email.com', 'a110j', '(14) 99110-1010');

# Tabela de Endereços (Opcional para pedidos de retirada)
insert into enderecos (id_cliente, rua, numero, bairro, cep, complemento) values
(1,'Rua das Rosas','123', 'Jardim Abacaxi', '19606-120', 'Casa'),
(2,'Rua das Petúnias','234', 'Jardim Maçã', '19607-123', 'Apto 7 Bloco B'),
(3,'Rua das Tulipas','456', 'Jardim Pera', '19888-456', 'Casa'),
(4,'Rua das Orquideas','678', 'Jardim Melancia', '19888-101', 'Apto 3 Predio 2'),
(5,'Rua das Palmeiras','975', 'Jardim Tomate', '19000-300', ''),
(6,'Rua dos Cravos','312', 'Jardim Limão', '18606-210', 'Fundos'),
(7,'Rua das Margaridas','789', 'Vila Hortência', '18609-440', 'Apto 14'),
(8,'Rua dos Lírios','154', 'Jardim Morango', '18607-320', 'Casa'),
(9,'Rua das Violetas','640', 'Jardim Uva', '18610-150', 'Bloco C Apto 5'),
(10,'Rua dos Girassóis','820', 'Vila Manga', '18600-180', '');

# Tabela de Categorias
insert into categorias (nome) values
('Esfihas Salgadas'),
('Esfihas Doces'),
('Pastéis Salgados'),
('Pastéis Doces'),
('Beirutes'),
('Porções'),
('Especialidades da Casa'),
('Bebidas'),
('Combos'),
('Kibes');

# Tabela de Produtos
insert into produtos (id_categoria, nome, descricao, preco, ativo) values
(1, 'Esfiha de Carne com Mussarela', 'Saborosa esfiha artesanal de carne com mussarela', 17.90, TRUE),
(2, 'Esfiha de Banana com Doce de Leite', 'Saborosa esfiha artesanal doce', 19.50, TRUE),
(3, 'Pastel de Bacalhau', 'Tradicional pastel de feira de Bacalhau', 17.90, TRUE),
(4, 'Pastel de Creme de Avelã', 'Pastel crocante recheado com chocolate creme de avelã', 22.50, TRUE),
(5, 'Beirute de Alcatra', 'Pão sírio recheado com alcatra, queijo, presunto, ovo, alface e tomate', 50.00, TRUE),
(6, 'Porção de Batata Frita com Cheddar e Bacon', 'Porção generosa de batatas crocantes cobertas com cheddar cremoso e bacon', 32.00, TRUE),
(7, 'Esfiha Especial Chaplin', 'Receita exclusiva da casa com carne temperada, catupiry original, bacon e alho frito', 21.90, TRUE),
(8, 'Refrigerante Lata 350ml', 'Bebida gelada nos sabores cola, guaraná ou laranja', 6.50, TRUE),
(9, 'Combo Família 6 Esfihas', 'Seleção especial com 16 esfihas salgadas tradicionais da casa', 60.00, TRUE),
(10, 'Kibe Frito Recheado com Catupiry', 'Kibe crocante por fora, macio por dentro e recheado com catupiry', 15.50, TRUE);

-- Tabela de Pedidos (10 registros)
INSERT INTO pedidos (id_cliente, id_endereco, tipo_entrega, status, forma_pagamento, valor_produtos, taxa_entrega, valor_total) VALUES
(1, 1, 'DELIVERY', 'FINALIZADO', 'PIX', 35.80, 6.00, 41.80),
(2, 2, 'DELIVERY', 'FINALIZADO', 'CARTAO_CREDITO', 60.00, 7.00, 67.00),
(3, NULL, 'RETIRADA', 'FINALIZADO', 'PIX', 24.40, 0.00, 24.40),
(4, 4, 'DELIVERY', 'SAIU_ENTREGA', 'DINHEIRO', 50.00, 6.00, 56.00),
(5, NULL, 'RETIRADA', 'FINALIZADO', 'CARTAO_DEBITO', 42.00, 0.00, 42.00),
(6, 6, 'DELIVERY', 'FINALIZADO', 'PIX', 43.80, 8.00, 51.80),
(7, 7, 'DELIVERY', 'PREPARO', 'CARTAO_CREDITO', 73.00, 6.50, 79.50),
(8, NULL, 'RETIRADA', 'PRONTO_RETIRADA', 'PIX', 31.00, 0.00, 31.00),
(9, 9, 'DELIVERY', 'FINALIZADO', 'CARTAO_DEBITO', 92.40, 7.50, 99.90),
(10, 10, 'DELIVERY', 'RECEBIDO', 'PIX', 34.40, 6.00, 40.40);

-- Tabela de Itens do Pedido (10 registros)
INSERT INTO itens_pedido (id_pedido, id_produto, quantidade, preco_unitario, observacao) VALUES
(1, 1, 2, 17.90, 'Sem cebola'),
(2, 9, 1, 60.00, 'Esfihas bem assadas'),
(3, 1, 1, 17.90, NULL),
(3, 8, 1, 6.50, 'Guaraná bem gelado'),
(4, 5, 1, 50.00, 'Sem tomate'),
(5, 6, 1, 32.00, 'Cheddar extra'),
(6, 7, 2, 21.90, 'Caprichar no alho frito'),
(7, 4, 2, 22.50, NULL),
(8, 10, 2, 15.50, 'Com limão à parte'),
(9, 9, 1, 60.00, NULL);