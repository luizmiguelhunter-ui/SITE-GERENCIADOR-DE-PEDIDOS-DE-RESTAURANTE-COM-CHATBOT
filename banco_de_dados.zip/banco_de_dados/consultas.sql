# Consulta 1
SELECT
    p.id_pedido,
    c.nome AS nome_cliente,
    c.telefone,
    p.tipo_entrega,
    p.status,
    p.forma_pagamento,
    p.valor_total
FROM pedidos p
INNER JOIN clientes c ON c.id_cliente = p.id_cliente
ORDER BY p.id_pedido ASC;

# Consulta 2
SELECT
    ip.id_item,
    ip.id_pedido,
    pr.nome AS nome_produto,
    ip.quantidade,
    ip.preco_unitario,
    COALESCE(ip.observacao, 'Sem observação') AS observacao
FROM itens_pedido ip
INNER JOIN produtos pr ON pr.id_produto = ip.id_produto
ORDER BY ip.id_pedido ASC, ip.id_item ASC;

# Consulta 3
SELECT
    pr.id_produto,
    ca.nome AS categoria,
    pr.nome AS produto,
    COUNT(ip.id_item) AS qtd_lancamentos,
    SUM(ip.quantidade) AS total_unidades_vendidas,
    SUM(ip.quantidade * ip.preco_unitario) AS faturamento_bruto
FROM itens_pedido ip
INNER JOIN produtos pr ON pr.id_produto = ip.id_produto
INNER JOIN categorias ca ON ca.id_categoria = pr.id_categoria
GROUP BY pr.id_produto, ca.nome, pr.nome
ORDER BY faturamento_bruto DESC, total_unidades_vendidas DESC;

# Consulta 4
SELECT
    c.id_cliente,
    c.nome AS cliente,
    e.bairro,
    COUNT(p.id_pedido) AS qtd_pedidos,
    SUM(p.valor_total) AS total_gasto,
    ROUND(AVG(p.valor_total), 2) AS ticket_medio
FROM clientes c
INNER JOIN pedidos p ON p.id_cliente = c.id_cliente
INNER JOIN enderecos e ON e.id_endereco = p.id_endereco
GROUP BY c.id_cliente, c.nome, e.bairro
ORDER BY total_gasto DESC;
